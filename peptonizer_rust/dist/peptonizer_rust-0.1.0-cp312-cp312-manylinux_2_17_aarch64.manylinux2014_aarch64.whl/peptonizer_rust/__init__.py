from .peptonizer_rust import *

__doc__ = peptonizer_rust.__doc__
if hasattr(peptonizer_rust, "__all__"):
    __all__ = peptonizer_rust.__all__